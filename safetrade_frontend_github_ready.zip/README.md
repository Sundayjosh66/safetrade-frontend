# Safetrade Frontend

## Instructions
1. Upload this folder to a new GitHub repo (e.g., safetrade-frontend).
2. Connect it to Vercel (https://vercel.com).
3. Vercel will auto-detect and deploy the static site.

Enjoy your frontend live at: https://yourproject.vercel.app
